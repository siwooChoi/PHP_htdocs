<?php

  session_start();


  $argTest1 = $_SESSION["test1"];
  $argTest2 = $_SESSION["test2"];

  // $argTest3 = $_COOKIE["test3"];

  echo $_SESSION["test1"];
  echo $_SESSION["test2"];
  // echo $argTest3;





 ?>
